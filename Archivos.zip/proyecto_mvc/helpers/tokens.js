import crypto from 'crypto';

const generarIdSeguro = () => {
    return crypto.randomBytes(32).toString('hex');
};

export { generarIdSeguro };
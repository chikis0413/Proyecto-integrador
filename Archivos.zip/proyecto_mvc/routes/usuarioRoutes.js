import express from 'express';
import { formularioregistro, registrar, inicio, formulariologin, autenticar, contrasena, cuenta } from '../controllers/usuarioController.js';
import verificarToken from '../middlewares/verificarToken.js';  // Asegúrate de la ruta correcta

const router = express.Router();

router.get('/registro', formularioregistro);  // Mostrar formulario de registro
router.post('/registro', registrar);          // Procesar registro de nuevo usuario
router.get('/inicio', inicio);                // Página de inicio para usuario registrado

router.get('/login', formulariologin);     // Mostrar formulario de login
router.post('/login', autenticar);          // Procesar inicio de sesión
router.get('/contrasena', contrasena);     // Mostrar formulario para recuperar contraseña

// Ruta protegida, solo accesible si el token es válido
router.get('/cuenta', verificarToken, cuenta); 

export default router;

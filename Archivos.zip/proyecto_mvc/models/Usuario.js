import { DataTypes } from 'sequelize'
import bcrypt from 'bcrypt'
import db from '../config/db.js'

const Usuario = db.define('usuarios', {
    nombre: {
        type: DataTypes.STRING(60),
        allowNull: false
    },
    apellido: {
        type: DataTypes.STRING(60),
        allowNull: false
    },
    nacimiento: {
        type: DataTypes.DATEONLY,
        allowNull: false
    },
    telefono: {
        type: DataTypes.BIGINT(10),
        allowNull: false
    },
    genero: {
        type: DataTypes.STRING(30),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(100),
        allowNull: false,
        unique: true // Asumiendo que el email debe ser único
    },
    password: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    token: DataTypes.STRING,
    confirmado: DataTypes.BOOLEAN
},  {
    hooks: {
        beforeCreate: async function(usuario) {
            const salt = await bcrypt.genSalt(10)
            usuario.password = await bcrypt.hash(usuario.password, salt);
        }
    }
})

export default Usuario
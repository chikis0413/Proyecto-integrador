import express from 'express';
import usuarioRoutes from './routes/UsuarioRoutes.js';  // Rutas de usuario
import db from './config/db.js';                        // Conexión a la base de datos
import dotenv from 'dotenv';                           // Manejo de variables de entorno
import cookieParser from 'cookie-parser';              // Middleware para cookies
import verificarToken from './middlewares/verificarToken.js';  // Middleware para verificar token

// Configuración de variables de entorno
dotenv.config();

// Crea la app de Express
const app = express();

// Middleware para leer datos de formularios
app.use(express.urlencoded({ extended: true }));

// Middleware para manejar cookies
app.use(cookieParser());

// Ruta protegida
app.get('/cuenta', verificarToken, (req, res) => {
    res.render('/cuenta', { usuario: req.usuario });
});

// Conectar a la base de datos
const conectarDB = async () => {
    try {
        await db.authenticate();  // Verifica la conexión a la base de datos
        console.log('Conexión correcta a la base de datos');
        // En producción, usar migraciones en lugar de `sync()`
        // db.sync()  // Sincroniza las tablas (evitar en producción)
    } catch (error) {
        console.log('Error en la conexión a la base de datos:', error);
    }
};
conectarDB();

// Configuración de motor de plantillas (Pug)
app.set('view engine', 'pug');
app.set('views', './views');  // Ruta donde se encuentran las vistas Pug

// Carpeta pública para archivos estáticos
app.use(express.static('public'));

// Routing
app.use('/auth', usuarioRoutes);  // Prefijo para rutas de autenticación

// Definir el puerto y arrancar el servidor
const port = process.env.PORT || 3000;

app.listen(port, () => {
    console.log(`El servidor está funcionando en el puerto ${port}`);
});

console.log('JWT_SECRET:', process.env.JWT_SECRET);  // Deberías ver 'mysecretkey'



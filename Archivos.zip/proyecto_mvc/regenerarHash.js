import bcrypt from 'bcryptjs';

// La contraseña original
const password = 'masculino';  // La contraseña ingresada que quieres actualizar

const generarHash = async () => {
    // Generar un nuevo hash
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    console.log("Nuevo hash generado:", passwordHash);
};

generarHash();

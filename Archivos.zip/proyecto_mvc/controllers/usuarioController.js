import { check, validationResult } from 'express-validator';
import Usuario from '../models/Usuario.js';
import { generarIdSeguro } from '../helpers/tokens.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const formulariologin = (req, res) => {
    res.render('auth/login');
};

const formularioregistro = (req, res) => {
    res.render('auth/registro', {
        pagina: 'Crear cuenta'
    });
};

const registrar = async (req, res) => {
    await check('nombre').notEmpty().withMessage('El nombre no puede ir vacío').run(req);
    await check('apellido').notEmpty().withMessage('El apellido no puede ir vacío').run(req);
    await check('nacimiento').notEmpty().withMessage('La fecha de nacimiento no puede ir vacía').run(req);
    await check('telefono').notEmpty().withMessage('El número de teléfono no puede ir vacío').run(req);
    await check('genero').notEmpty().withMessage('El género no puede ir vacío').run(req);
    await check('email').isEmail().withMessage('El correo electrónico no es válido').run(req);
    await check('password').isLength({ min: 6 }).withMessage('La contraseña debe tener al menos 6 caracteres').run(req);
    await check('repetir_password').custom((value, { req }) => {
        if (value !== req.body.password) {
            throw new Error('La contraseña no es la misma');
        }
        return true;
    }).run(req);

    const resultado = validationResult(req);
    if (!resultado.isEmpty()) {
        return res.render('auth/registro', {
            pagina: 'Crear Cuenta',
            errores: resultado.array(),
            usuario: req.body
        });
    }

    const { nombre, apellido, nacimiento, telefono, genero, email, password } = req.body;

    const existeUsuario = await Usuario.findOne({ where: { email } });
    if (existeUsuario) {
        return res.render('auth/registro', {
            pagina: 'Crear Cuenta',
            errores: [{ msg: 'El usuario ya está registrado' }],
            usuario: req.body
        });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);
    console.log("Password hash generado:", passwordHash); // Agrega este console.log
    console.log("Contraseña ingresada:", password);  // Debe mostrar la contraseña que el usuario escribe


    const usuario = await Usuario.create({
        nombre,
        apellido,
        nacimiento,
        telefono,
        genero,
        email,
        password: passwordHash,
        token: generarIdSeguro()
    });

    res.render('templates/mensaje');
};

const inicio = (req, res) => {
    res.render('auth/inicio');
};

const contrasena = (req, res) => {
    res.render('auth/contrasena');
};

const cuenta = (req, res) => {
    res.render('auth/cuenta');
};

const autenticar = async (req, res) => {
    await check('email').isEmail().withMessage('Correo no válido').run(req);
    await check('password').notEmpty().withMessage('La contraseña es obligatoria').run(req);

    let resultado = validationResult(req);

    if (!resultado.isEmpty()) {
        return res.render('auth/login', {
            errores: resultado.array(),
            usuario: { email: req.body.email }
        });
    }

    const { email, password } = req.body;

    try {
        const usuario = await Usuario.findOne({ where: { email } });
        if (!usuario) {
            return res.render('templates/sesion', {
                errores: [{ msg: 'Usuario no existe' }],
                usuario: { email }
            });
        }

        // Comparar contraseñas
        const passwordCorrecto = await bcrypt.compare(password, usuario.password);
        console.log("Contraseña ingresada:", password);
        console.log("Hash de la base de datos:", usuario.password);
        console.log("¿Password correcto?", passwordCorrecto);

        if (!passwordCorrecto) {
            return res.render('templates/sesion', {
                errores: [{ msg: 'Contraseña incorrecta' }],
                usuario: { email }
            });
        }

        // Generar token JWT
        const token = jwt.sign({ id: usuario.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        
        res.cookie('token', token, {
            httpOnly: true,  // No debe ser accesible desde el cliente (JavaScript)
            secure: false,   // Deberías usar `true` en producción si usas HTTPS
        });

        return res.redirect('cuenta');
    } catch (error) {
        console.error(error);
        return res.status(500).send('Error en el servidor');
    }
};



export {
    formulariologin,
    formularioregistro,
    registrar,
    inicio,
    contrasena,
    autenticar,
    cuenta
};

import jwt from 'jsonwebtoken';

const verificarToken = (req, res, next) => {
    const token = req.cookies.token;

    if (!token) {
        return res.status(403).send('Acceso denegado.');
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(401).send('Token no válido.');
        }
        req.usuario = decoded;
        next();
    });
};

export default verificarToken;
